# Tufts University Plant Cell Culture Library (PCCL): collection data

Data as of 2026-11-12, the last time the collection's data changed. What changed in this release is listed on the site's What changed page, under 12 November 2026.

The Tufts University Plant Cell Culture Library is a collection of plant cell lines hosted at the Tufts University Innovation Hub for Food and Materials in Medford, Massachusetts, in collaboration with the Tufts University Center for Cellular Agriculture. These files hold the data its website shows: 1544 species, 1605 held lines and 36 media recipes.

## Licence

No licence has been chosen for this data yet. The terms for reusing it are still being settled. For questions about reuse, write to cellag@tufts.edu. The same words are in LICENSE.txt.

## The files

Each table comes twice, as CSV and as JSON. The CSV files are UTF-8 with a byte-order mark, so Excel reads accents and the hybrid sign (×) correctly. A CSV field that starts with =, +, -, @ or a tab has an apostrophe added in front, so a spreadsheet shows it as text instead of running it as a formula. The JSON files give every value exactly, and lists as lists, and each also carries the data date and the licence.

### pccl-species-2026-11-12.csv and pccl-species-2026-11-12.json

One row per species with at least one held line.

| Column | What it holds |
| --- | --- |
| species_id | PCCL's ID for the species, as in its page address. Never given to another species. |
| name | The species' accepted scientific name, as the lab uses it. |
| authorship | The name's author citation, where the name has been matched to World Flora Online. Empty otherwise. |
| genus | Its genus. |
| family | Its family. |
| order | Its order. |
| common_names | Its common names from the lab's records, separated by "; ". |
| species_activities | Bioactivities reported for the species, separated by "; ". |
| genus_activities | Bioactivities reported for its genus, separated by "; ". |
| wfo_id | Its World Flora Online ID, where the name has been matched. Empty otherwise. |
| ipni_id | Its International Plant Names Index (IPNI) ID, where the name has been matched. Empty otherwise. |
| held_lines | How many held lines of the species the collection has. |

### pccl-lines-2026-11-12.csv and pccl-lines-2026-11-12.json

One row per held line: a cell line the lab still keeps, live, in cryo, or with neither yet recorded. A line can be kept as more than one stock, on different media: the CSV gives the line one row that combines its stocks, and the JSON lists each stock with its own medium, status and growth.

| Column | What it holds |
| --- | --- |
| line_id | PCCL's ID for the line. Never given to another line. |
| culture_id | The lab's Culture ID. The line's page address is the Culture ID with spaces as hyphens. |
| species_id | The species' ID, as in the species file. |
| species | The species' accepted name. |
| status | Live & cryopreserved, Cryopreserved, or Not recorded: live if any of its stocks is kept live, cryopreserved if any is cryopreserved. |
| media | The Media Codes of the media its stocks are kept on, separated by "; ". Empty where none is recorded. A medium may have no recipe in the media file yet. |
| growth | The highest growth rate recorded for its stocks, from 1 (slow) to 5 (fast). Empty where none is recorded. |
| available_to_request | true if the line can be requested. |
| stocks | In the JSON only: each stock the line is kept as, with its own medium (a Media Code, or null where none is recorded), status and growth, where the CSV combines them in one row. |

### pccl-media-2026-11-12.csv and pccl-media-2026-11-12.json

One row per reagent of each recipe, in the order the medium is made. Amounts are per liter of medium.

| Column | What it holds |
| --- | --- |
| medium | The Media Code, as in the lines file and the medium's page address. |
| ph | The pH the medium is adjusted to. |
| step | When the reagent goes in. components: dissolved first, before the volume is made up to 1 L and the pH adjusted. gel: the gelling agent, added before autoclaving. vitamins: added after autoclaving, before pouring. |
| reagent | The reagent. |
| stock | The concentration of the stock solution it is added from, where it is added from one. |
| amount | How much to add per liter of medium, in the unit given. |
| unit | The unit of the amount. |
| vendor | The supplier the lab buys it from. |
| catalog_number | The supplier's catalog number. |
| steps | In the JSON only: the recipe's reagents under the step each goes in (components, gel, vitamins), each with its reagent, stock, amount, unit, vendor and catalog_number, as in the CSV. |

## Questions

Write to cellag@tufts.edu.
